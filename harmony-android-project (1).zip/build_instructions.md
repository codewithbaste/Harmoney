# How to Build Harmony Android APK

Since the Replit environment has limitations for full Android development, here are the complete instructions to build your APK:

## Option 1: Android Studio (Recommended)

1. **Download the project files**:
   - Download all files from the `android-app` folder
   - Extract to your computer

2. **Open in Android Studio**:
   - Open Android Studio
   - Select "Open an existing project"
   - Choose the `android-app` folder

3. **Build the APK**:
   - Wait for Gradle sync to complete
   - Go to `Build > Build Bundle(s) / APK(s) > Build APK(s)`
   - APK will be generated in `app/build/outputs/apk/debug/`

## Option 2: Online Build Services

### GitHub Actions (Free)
1. Upload project to GitHub
2. Add this workflow file (`.github/workflows/android.yml`):

```yaml
name: Android CI
on: [push]
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v3
    - name: Set up JDK 17
      uses: actions/setup-java@v3
      with:
        java-version: '17'
        distribution: 'temurin'
    - name: Setup Android SDK
      uses: android-actions/setup-android@v2
    - name: Build APK
      run: |
        cd android-app
        chmod +x gradlew
        ./gradlew assembleDebug
    - name: Upload APK
      uses: actions/upload-artifact@v3
      with:
        name: harmony-app
        path: android-app/app/build/outputs/apk/debug/app-debug.apk
```

### AppCenter (Microsoft)
1. Sign up at appcenter.ms
2. Connect your repository
3. Configure Android build
4. Download generated APK

## Option 3: Local Command Line

If you have Android SDK installed locally:

```bash
# Download and install Android SDK
# Set ANDROID_HOME environment variable

cd android-app
chmod +x gradlew
./gradlew assembleDebug
```

## What You Get

The APK will include:
- ✅ WebView with your Harmony web app
- ✅ Splash screen with app branding
- ✅ Material Design 3 theme
- ✅ Support for both custom domain and Replit fallback
- ✅ Pull-to-refresh functionality
- ✅ Proper Android navigation
- ✅ Network permissions for real-time features
- ✅ WebSocket and localStorage support

## File Size
- Debug APK: ~8-15 MB
- Release APK: ~5-8 MB (after ProGuard optimization)

## Installation
1. Enable "Unknown Sources" in Android settings
2. Transfer APK to Android device
3. Tap APK file to install
4. Open Harmony app and sign in!

Would you like me to guide you through any of these options?