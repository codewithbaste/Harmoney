#!/bin/bash

echo "Building Harmony Android APK..."

# Set Android environment variables
export ANDROID_HOME="/nix/store/android-sdk"
export JAVA_HOME="/nix/store/jdk17"

# Create simple launcher icons (PNG format)
echo "Creating app icons..."
# Create a simple 48x48 pixel icon using ImageMagick if available
if command -v convert >/dev/null 2>&1; then
    # Create different sized icons
    convert -size 48x48 xc:'#6366f1' -fill white -font Arial-Bold -pointsize 20 -gravity center -annotate +0+0 'H' app/src/main/res/mipmap-mdpi/ic_launcher.png
    convert -size 72x72 xc:'#6366f1' -fill white -font Arial-Bold -pointsize 30 -gravity center -annotate +0+0 'H' app/src/main/res/mipmap-hdpi/ic_launcher.png
    convert -size 96x96 xc:'#6366f1' -fill white -font Arial-Bold -pointsize 40 -gravity center -annotate +0+0 'H' app/src/main/res/mipmap-xhdpi/ic_launcher.png
    convert -size 144x144 xc:'#6366f1' -fill white -font Arial-Bold -pointsize 60 -gravity center -annotate +0+0 'H' app/src/main/res/mipmap-xxhdpi/ic_launcher.png
    convert -size 192x192 xc:'#6366f1' -fill white -font Arial-Bold -pointsize 80 -gravity center -annotate +0+0 'H' app/src/main/res/mipmap-xxxhdpi/ic_launcher.png
    
    # Create round icons
    cp app/src/main/res/mipmap-mdpi/ic_launcher.png app/src/main/res/mipmap-mdpi/ic_launcher_round.png
    cp app/src/main/res/mipmap-hdpi/ic_launcher.png app/src/main/res/mipmap-hdpi/ic_launcher_round.png
    cp app/src/main/res/mipmap-xhdpi/ic_launcher.png app/src/main/res/mipmap-xhdpi/ic_launcher_round.png
    cp app/src/main/res/mipmap-xxhdpi/ic_launcher.png app/src/main/res/mipmap-xxhdpi/ic_launcher_round.png
    cp app/src/main/res/mipmap-xxxhdpi/ic_launcher.png app/src/main/res/mipmap-xxxhdpi/ic_launcher_round.png
else
    echo "ImageMagick not available, using text files as placeholders..."
    # Create placeholder files
    echo "Harmony Icon" > app/src/main/res/mipmap-mdpi/ic_launcher.png
    echo "Harmony Icon" > app/src/main/res/mipmap-hdpi/ic_launcher.png
    echo "Harmony Icon" > app/src/main/res/mipmap-xhdpi/ic_launcher.png
    echo "Harmony Icon" > app/src/main/res/mipmap-xxhdpi/ic_launcher.png
    echo "Harmony Icon" > app/src/main/res/mipmap-xxxhdpi/ic_launcher.png
    cp app/src/main/res/mipmap-mdpi/ic_launcher.png app/src/main/res/mipmap-mdpi/ic_launcher_round.png
    cp app/src/main/res/mipmap-hdpi/ic_launcher.png app/src/main/res/mipmap-hdpi/ic_launcher_round.png
    cp app/src/main/res/mipmap-xhdpi/ic_launcher.png app/src/main/res/mipmap-xhdpi/ic_launcher_round.png
    cp app/src/main/res/mipmap-xxhdpi/ic_launcher.png app/src/main/res/mipmap-xxhdpi/ic_launcher_round.png
    cp app/src/main/res/mipmap-xxxhdpi/ic_launcher.png app/src/main/res/mipmap-xxxhdpi/ic_launcher_round.png
fi

# Make gradlew executable
chmod +x gradlew 2>/dev/null || echo "No gradlew found, using gradle directly"

# Clean and build
echo "Building APK..."
if [ -f gradlew ]; then
    ./gradlew clean assembleDebug
else
    gradle clean assembleDebug
fi

# Check if APK was created
if [ -f app/build/outputs/apk/debug/app-debug.apk ]; then
    echo "✓ APK built successfully!"
    echo "APK location: app/build/outputs/apk/debug/app-debug.apk"
    cp app/build/outputs/apk/debug/app-debug.apk harmony-app.apk
    echo "✓ APK copied to: harmony-app.apk"
    ls -la harmony-app.apk
else
    echo "❌ APK build failed. Check the logs above."
fi