#!/usr/bin/env python3
"""
Create Android app icons from SVG
"""
import os

# Create a simple SVG icon for the app
svg_content = '''<?xml version="1.0" encoding="UTF-8"?>
<svg width="192" height="192" viewBox="0 0 192 192" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <linearGradient id="grad1" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" style="stop-color:#6366f1;stop-opacity:1" />
      <stop offset="100%" style="stop-color:#8b5cf6;stop-opacity:1" />
    </linearGradient>
  </defs>
  
  <!-- Background circle -->
  <circle cx="96" cy="96" r="88" fill="url(#grad1)" stroke="#4f46e5" stroke-width="4"/>
  
  <!-- Hearts symbol -->
  <g transform="translate(96,96)">
    <!-- Left heart -->
    <path d="M-20,-10 C-30,-25 -50,-25 -50,-10 C-50,5 -20,25 -20,25 C-20,25 -20,5 -20,-10 Z" fill="white" opacity="0.9"/>
    <!-- Right heart -->
    <path d="M20,-10 C30,-25 50,-25 50,-10 C50,5 20,25 20,25 C20,25 20,5 20,-10 Z" fill="white" opacity="0.9"/>
    <!-- Center connection -->
    <circle cx="0" cy="0" r="8" fill="white"/>
    <!-- H letter -->
    <text x="0" y="6" text-anchor="middle" font-family="Arial, sans-serif" font-size="16" font-weight="bold" fill="#6366f1">H</text>
  </g>
</svg>'''

# Write SVG file
with open('android-app/app_icon.svg', 'w') as f:
    f.write(svg_content)

print("Created app_icon.svg")