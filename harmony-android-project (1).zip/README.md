# Harmony Android App

This is the Android WebView wrapper for the Harmony relationship app.

## Features

- **Native Android App**: Built with modern Android development practices
- **WebView Integration**: Displays your web app (https://dailypipes.in) in a native container
- **Fallback Support**: Automatically falls back to Replit URL if custom domain unavailable
- **Material Design**: Beautiful native Android UI with splash screen
- **Full WebView Features**: JavaScript, localStorage, WebSocket support
- **Pull-to-Refresh**: Native swipe-to-refresh functionality
- **Responsive**: Adapts to different screen sizes and orientations

## Building the APK

### Prerequisites

1. **Android Studio** installed with Android SDK
2. **Java 17** or higher
3. **Gradle 8.0** or higher

### Build Steps

1. Open Android Studio
2. Import this project (`android-app` folder)
3. Sync Gradle files
4. Build APK: `Build > Build Bundle(s) / APK(s) > Build APK(s)`

### Alternative: Command Line Build

```bash
cd android-app
./gradlew assembleDebug
```

The APK will be generated at: `app/build/outputs/apk/debug/app-debug.apk`

## App Configuration

### URLs
- **Primary URL**: `https://dailypipes.in`
- **Fallback URL**: `https://f16b5734-2bc2-4db7-b92f-9254a47d2239-00-3637wpnnooq7f.picard.replit.dev`

### Features Enabled
- JavaScript execution
- Local storage
- WebSocket connections
- Geolocation (if needed)
- Camera/microphone permissions (for future features)

## Installation

1. Enable "Install unknown apps" for your browser or file manager
2. Download the APK file
3. Tap to install
4. Open the Harmony app
5. Sign in with Google and connect with your partner

## App Structure

- `MainActivity.kt`: Main WebView activity with all web app functionality
- `SplashActivity.kt`: Beautiful splash screen with app branding
- Modern Material Design 3 theme
- Proper error handling and network fallbacks
- Native Android navigation (back button support)

## Next Steps for Production

1. **Sign the APK** with a release keystore
2. **Upload to Google Play Store** for distribution
3. **Add App Bundle support** for optimized downloads
4. **Implement push notifications** for partner actions
5. **Add biometric authentication** for security

The Android app provides a native mobile experience while using the same web technology and real-time features you've already built!